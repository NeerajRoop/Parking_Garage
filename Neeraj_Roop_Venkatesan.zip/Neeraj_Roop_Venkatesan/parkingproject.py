import os
from flask import Flask, redirect, render_template, request
import json
import time
import threading

app = Flask(__name__, static_url_path='')

global counter
counter=0

#Seperate thread to keep track of number of requests in 10 seconds interval
@app.before_first_request
def activate_job():
    def run_job():
        global counter
        while True:
            x = 10
            while x > 0:
                x-=1
                time.sleep(1)
            x=10
            counter=0
    thread = threading.Thread(target=run_job)
    thread.start()

#slot information array 
slots = ['Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty','Empty']


@app.route("/", methods=["POST", "GET"])
def getdata():
   
    return render_template('main.html', slot=slots)

#function to park a car in a empty slot
@app.route("/Park", methods=["POST", "GET"])
def Park():
    global counter
    counter+=1
    #If number of request exceeds 10 within 10 seconds, then error page opens
    if(counter>10):
        return render_template('error.html')
    check=0
    carslot='Slot is full'
    number= request.form.get("car_number")
    for i in slots:
        if i==number:
            check=1
            break
    if(check==0):
        for i in range(len(slots)):
            if(slots[i]=='Empty'):
                slots[i]=number
                carslot=i+1
                break


    return render_template('info.html', slotnumber = carslot, slot=slots, carnumber=number)

#function to unpark a car
@app.route("/Unpark", methods=["POST", "GET"])
def Unpark():
    global counter
    #If number of request exceeds 10 within 10 seconds, then error page opens
    counter=counter+1
    if(counter>10):
        return render_template('error.html')
    number= int(request.form.get("slot_number"))
    slots[number-1]='Empty'
    
    return render_template('main.html', slot=slots)

#Get car number for the given slot number
@app.route("/Slotinfo", methods=["POST", "GET"])
def Slotinfo():
    global counter
    #If number of request exceeds 10 within 10 seconds, then error page opens
    counter+=1
    if(counter>10):
        return render_template('error.html')
    number1= int(request.form.get("slot_number"))
    number1=number1-1 
    slotnumber=number1+1
    

    if(1>slotnumber):
        return render_template('info2.html', slot=slots)
        
    if(slotnumber>len(slots)):
        return render_template('info2.html', slot=slots)

    carnumber=slots[number1]  

    
    return render_template('info.html', slot=slots, slotnumber=slotnumber, carnumber=carnumber)

    

#get the slot information if the car is parked
@app.route("/Slotinfo1", methods=["POST", "GET"])
def Slotinfo1():
    global counter
    #If number of request exceeds 10 within 10 seconds, then error page opens
    counter+=1
    if(counter>10):
        return render_template('error.html')
    check=0
    number1= request.form.get("car_number")
 
    for i in range(len(slots)):
        if slots[i]==number1:
            slotnumber=i+1
            carnumber=number1
            check=1
            break

    if check==0:
        return render_template('info2.html', slot=slots)
    else:
        return render_template('info.html', slot=slots, slotnumber=slotnumber, carnumber=carnumber)

#View the parking slots
@app.route("/View", methods=["POST", "GET"])
def View():
    global counter
    counter+=1
    if(counter>10):
        return render_template('error.html')
   
    return render_template('View.html', slot=slots)

port = os.getenv('PORT', '5000')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(port))
